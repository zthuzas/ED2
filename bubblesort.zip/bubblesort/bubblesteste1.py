#import random
from bubblesort import bubblesort

lista = [11, 4, 30, 22, 7, 26]
print("Lista Desorndenada: ", lista)
print("")

bubblesort(lista)
print("Lista ordenada: ", lista)